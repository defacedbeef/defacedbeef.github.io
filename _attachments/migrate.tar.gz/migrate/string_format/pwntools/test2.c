#include <stdio.h>
#include <string.h>

const char* flag = "THE_FLAG";

int main()
{
	char buffer[1024];
    for(;;) {
	fgets(buffer, sizeof(buffer), stdin);
	printf(buffer);
    }
}
