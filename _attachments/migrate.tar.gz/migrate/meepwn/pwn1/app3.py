from __future__ import print_function
from flask import Flask, Response, render_template, session, request, jsonify, send_file
import os
from subprocess import STDOUT, PIPE, CalledProcessError, Popen, run
from base64 import b64decode, b64encode
import codecs
import time

app = Flask(__name__)
app.secret_key = open('private/secret.txt').read()

@app.route('/')
def main():
    if session.get('ISBADSYSCALL') == None:
        session['ISBADSYSCALL'] = False
    return render_template('index.html', name="BABY")

        
@app.route('/exploit', methods=['POST'])
def exploit():
    
    try:
        data = request.get_json(force=True)
    except Exception:
        return jsonify({'result': 'Wrong data!'})
    
    try:
        payload = b64decode(data['payload'].encode())
    except:
        return jsonify({'result': 'Wrong data!'})
    
    test_i386(UC_MODE_32, payload)
    
    if session['ISBADSYSCALL']:
        return jsonify({'result': 'Bad Syscall!'})
    try:
        run(['nc', 'localhost', '9999'], input=payload, timeout=2, check=True)
        p = Popen(['nc', 'localhost', '9999'], stdin=PIPE) 
        p.communicate(payload)
    except CalledProcessError:
        return jsonify({'result': 'Error run file!'})
        
    return jsonify({'result': "DONE!"})
        

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080)
