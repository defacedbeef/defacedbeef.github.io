import sys
from base64 import b64decode, b64encode
import requests
import json


URL='127.0.0.1:8080'
URL1='http://{}/'.format(URL)
URL2='http://{}/exploit'.format(URL)

data = {"payload": "{}".format( b64encode(asm("nop"))  )}

session = requests.Session()



