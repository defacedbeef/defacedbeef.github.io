#include <stdio.h>
#include <signal.h>

static void sighandler(int signum) 
{
    char *argv[]={"/bin/echo","parameter test", NULL};

    execve("/bin/echo", argv, NULL);

    printf("catched sigsegv\n");
    char* b = 0;

    exit(0);
}

int main()
{
    signal(SIGSEGV, sighandler);    
    __asm__("int $0x0");
}
