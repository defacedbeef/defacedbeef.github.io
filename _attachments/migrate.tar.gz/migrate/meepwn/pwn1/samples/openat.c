#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

int main()
{
    int fd = openat(AT_FDCWD,"flag",O_RDONLY);
    close(fd);
}
