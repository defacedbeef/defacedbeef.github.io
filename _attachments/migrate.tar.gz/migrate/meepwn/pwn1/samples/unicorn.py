from unicorn import *
from unicorn.x86_const import *

def hook_intr(uc, intno, user_data):
    if intno != 0x80:
        uc.emu_stop()
        return
    eax = uc.reg_read(UC_X86_REG_EAX)
    if eax in BADSYSCALL:
        session['ISBADSYSCALL'] = True
        uc.emu_stop()

def test_i386(mode, code):
    try:
        mu = Uc(UC_ARCH_X86, mode)
        mu.mem_map(ADDRESS, 2 * 1024 * 1024)
        mu.mem_write(ADDRESS, code)
        mu.reg_write(UC_X86_REG_ESP, ADDRESS + 0x200000)
        mu.hook_add(UC_HOOK_INTR, hook_intr)
        mu.emu_start(ADDRESS, ADDRESS + len(code))
    except UcError as e:
        print("ERROR: %s" % e)



#test_i386(UC_MODE_32, payload)
