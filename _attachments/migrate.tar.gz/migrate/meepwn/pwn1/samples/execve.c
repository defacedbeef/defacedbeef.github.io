#include <unistd.h>
int main()
{
    char *argv[] = { "/bin/ls", NULL};

}

