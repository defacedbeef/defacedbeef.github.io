from __future__ import print_function
from flask import Flask, Response, render_template, session, request, jsonify, send_file
import os
from subprocess import STDOUT, PIPE, CalledProcessError, call
from base64 import b64decode, b64encode
import codecs
import time

app = Flask(__name__)
app.secret_key = open('private/secret.txt').read()



@app.route('/')
def main():
    if session.get('ISBADSYSCALL') == None:
        session['ISBADSYSCALL'] = False
    return render_template('index.html', name="BABY")

    
@app.route('/source', methods=['GET'])
def resouce():
    return send_file("app.py")

@app.route('/bin', methods=['GET'])
def bin():
    return send_file("/home/babysandbox/babysandbox")

        
@app.route('/exploit', methods=['POST'])
def exploit():
    try:
        data = request.get_json(force=True)
    except Exception:
        return jsonify({'result': 'Wrong data!'})
    
    try:
        payload = b64decode(data['payload'].encode())
    except:
        return jsonify({'result': 'Wrong data!'})
    
    try:
        call(['nc', 'localhost', '9999'])
    except CalledProcessError:
        return jsonify({'result': 'Error run file!'})
        
    return jsonify({'result': "DONE!"})
        

if __name__ == '__main__':
    app.run(host='localhost', port=8080)
