from __future__ import print_function
from unicorn import *
from unicorn.x86_const import *

ADDRESS = 0x1000000
sys_fork = 2
sys_read = 3
sys_write = 4
sys_open = 5
sys_close = 6
sys_execve = 11
sys_access = 33
sys_dup = 41
sys_dup2 = 63
sys_mmap = 90
sys_munmap = 91
sys_mprotect = 125
sys_sendfile = 187
sys_sendfile64 = 239
BADSYSCALL = [sys_fork, sys_read, sys_write, sys_open, sys_close, sys_execve, sys_access, sys_dup, sys_dup2, sys_mmap, sys_munmap, sys_mprotect, sys_sendfile, sys_sendfile64]


def test_i386(code):
    try:
        # Initialize emulator
        mu = Uc(UC_ARCH_X86, UC_MODE_32)
        mu.mem_map(ADDRESS, 2 * 1024 * 1024)
        mu.mem_write(ADDRESS, code)
        mu.reg_write(UC_X86_REG_ESP, ADDRESS + 0x200000)
        mu.emu_start(ADDRESS, ADDRESS + len(code))
    except UcError as e:
        print("ERROR: %s" % e)


