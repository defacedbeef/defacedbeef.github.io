#include <stdio.h>
#include <unistd.h>

char *argv[]={"/bin/echo","parameter test", NULL};

int main()
{
    execve("/bin/echo", argv, NULL);
}

