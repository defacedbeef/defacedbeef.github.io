#include <stdio.h>


const char* g_qrcode = "PSDCTF{codes_everywhere!}";

int main()
{
    printf("%s\n", g_qrcode);
}

