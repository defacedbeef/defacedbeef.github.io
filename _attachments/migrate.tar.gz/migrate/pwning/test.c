int main(int ac, char** av) 
{
	char buff[32];
	buff[0] = 1;
}
