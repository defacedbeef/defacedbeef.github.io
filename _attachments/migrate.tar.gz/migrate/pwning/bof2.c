#include <unistd.h>
#include <stdio.h>


void hempf()
{
	char buf[4];
	fgets(buf, 4, stdin);
	(*(void(*)())buf)();
}

int main()
{
	alarm(15);
	hempf();
}
