from pwn import *

human_size = 24

read_size = human_size * 2 # due two heap allocations

log.info('allocating ' + read_size + ' bytes')




