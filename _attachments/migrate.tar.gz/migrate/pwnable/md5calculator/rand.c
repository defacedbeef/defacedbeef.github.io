#include <time.h>
#include <stdlib.h>
#include <stdio.h>

int main(int argc, char *argv[])
{
    int j, r, nloops;
    unsigned int seed;

//    getchar();

    seed = time(0);
//    printf("%d\n", seed);
    srand(seed);
    for (j = 0; j < 8; j++) {
        r =  rand();
        printf("%d\n", r);
    }

    exit(EXIT_SUCCESS);
}
