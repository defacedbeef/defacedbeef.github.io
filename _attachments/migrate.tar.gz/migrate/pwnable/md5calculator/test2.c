#include <stdio.h>
#include <string.h>
char wtf[64];
char g_buff[1024];

int calcDecodeLength(const char *a1)
{
  unsigned int v1; // kr04_4
  int v3; // [esp+18h] [ebp-10h]

  v1 = strlen(a1) + 1;
  v3 = 0;
  if ( a1[v1 - 2] != 61 || a1[v1 - 3] != 61 )
  {
    if ( a1[v1 - 2] == 61 )
      v3 = 1;
  }
  else
  {
    v3 = 2;
  }
  return (int)((long double)(int)(v1 - 1) * 0.75 - (long double)v3);
}


int main()
{
    memset(wtf,61,sizeof(wtf));
    memset(g_buff,62,sizeof(g_buff));
    printf("%d\n", calcDecodeLength(g_buff));
}
