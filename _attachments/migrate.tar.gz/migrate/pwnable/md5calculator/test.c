#include <stdio.h>

#include <string.h>
#include <stdlib.h>
#include <unistd.h>

char buff[1024];
int main()
{
    memset(buff,0,sizeof(buff));
    fgets(buff, sizeof(buff), stdin);


}
