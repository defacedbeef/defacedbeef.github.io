/**************************************************************************\
|
| Version
| =======
| version 1.0, January 2012.
| 
| Copyright
| =========
| � Marc Stevens, 2012. All rights reserved.
| Contact: marc @ marc-stevens .nl
|
| Disclaimer
| ==========
| This software is provided as is. Use is at the user's risk.
| No guarantee whatsoever is given on how it may function or malfunction.
| Support cannot be expected.
| This software is meant for scientific and educational purposes only.
| It is forbidden to use it for other than scientific or educational purposes.
| In particular, commercial and malicious use is not allowed.
| Further distribution of this software, by whatever means, is not allowed
| without our consent.
| This includes publication of source code or executables in printed form,
| on websites, newsgroups, CD-ROM's, etc.
| Changing the (source) code without our consent is not allowed.
| In all versions of the source code this disclaimer, the copyright
| notice and the version number should be present.
|
\**************************************************************************/

#ifndef HASHATTACK_TIMER_HPP
#define HASHATTACK_TIMER_HPP


	class timer_detail;
	class timer {
	public:
		timer(bool direct_start = false);
		~timer();
		void start();
		void stop();
		double time() const;// get time between start and stop (or now if still running) in seconds
		bool isrunning() const { return running; } // check if timer is running

	private:
		timer_detail* detail;
		bool running;
	};


#endif // HASHATTACK_TIMER_HPP
