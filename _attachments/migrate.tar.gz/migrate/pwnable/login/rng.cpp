/**************************************************************************\
|
| Version
| =======
| version 1.0, January 2012.
| 
| Copyright
| =========
| � Marc Stevens, 2012. All rights reserved.
| Contact: marc @ marc-stevens .nl
| 
| Disclaimer
| ==========
| This software is provided as is. Use is at the user's risk.
| No guarantee whatsoever is given on how it may function or malfunction.
| Support cannot be expected.
| This software is meant for scientific and educational purposes only.
| It is forbidden to use it for other than scientific or educational purposes.
| In particular, commercial and malicious use is not allowed.
| Further distribution of this software, by whatever means, is not allowed
| without our consent.
| This includes publication of source code or executables in printed form,
| on websites, newsgroups, CD-ROM's, etc.
| Changing the (source) code without our consent is not allowed.
| In all versions of the source code this disclaimer, the copyright
| notice and the version number should be present.
|
\**************************************************************************/

#include <time.h>
#include "main.hpp"

#if defined(__linux__) || defined (__FreeBSD__)
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>    // open
#include <unistd.h>   // read, close
	void getosrnd(uint32 buf[256])
	{
		int fd;
		if ((fd = open("/dev/urandom", O_RDONLY)) < 0) return;
		read(fd, reinterpret_cast<char*>(buf), sizeof(buf));
		close(fd);
	}
#endif

#if defined(WIN32)
#include <windows.h>
#include <wincrypt.h>
	void getosrnd(uint32 buf[256])
	{
		HCRYPTPROV g_hCrypt;
		if(!CryptAcquireContext(&g_hCrypt,NULL,NULL,PROV_RSA_FULL,CRYPT_VERIFYCONTEXT))
			return;
		CryptGenRandom(g_hCrypt,sizeof(buf),reinterpret_cast<BYTE*>(buf));
		CryptReleaseContext(g_hCrypt,0);
	}
#endif

	void getosrnd(uint32 buf[256]);

	uint32 seedd;
	uint32 seed32_1;
	uint32 seed32_2;
	uint32 seed32_3;
	uint32 seed32_4;
	uint64 seed64;

	void seed(uint32 s)
	{
		seedd = 0;
		seed32_1 = s;
		seed32_2 = 2;
		seed32_3 = 3;
		seed32_4 = 4;
		for (unsigned i = 0; i < 0x1000; ++i)
			xrng128();
		seed64 = (uint64(seed32_1) << 32) + uint64(seed32_2);
	}

	void seed(uint32* sbuf, unsigned len)
	{
		seedd = 0;
		seed32_1 = 1;
		seed32_2 = 2;
		seed32_3 = 3;
		seed32_4 = 4;
		for (unsigned i = 0; i < len; ++i)
		{
			seed32_1 ^= sbuf[i];
			xrng128();
		}
		for (unsigned i = 0; i < 0x1000; ++i)
			xrng128();
		seed64 = (uint64(seed32_1) << 32) + uint64(seed32_2);
	}

	void addseed(uint32 s)
	{
		xrng128();
		seed32_1 ^= s;
		xrng128();
	}

	void addseed(const uint32* sbuf, unsigned len)
	{
		xrng128();
		for (unsigned i = 0; i < len; ++i)
		{
			seed32_1 ^= sbuf[i];
			xrng128();
		}
	}

	struct hashutil5_rng__init {
		hashutil5_rng__init()
		{
			seed(uint32(time(NULL)));
			uint32 rndbuf[256];
			for (unsigned i = 0; i < 256; ++i) rndbuf[i] = 0;
			getosrnd(rndbuf);
			addseed(rndbuf, 256);
		}
	};
	hashutil5_rng__init hashutil4_rng__init__now;

	void hashutil5_rng_hpp_init()
	{
		hashutil5_rng__init here;
	}
