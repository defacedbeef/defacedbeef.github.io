# pwnable.kr - login@rookies with radare2


### load binary


```
noname@noname-VirtualBox:~/projects/pwnable/login$ r2 ./login
Warning: Cannot initialize dynamic strings
 -- Don't trust what can't be compiled

```

### run in debug

From the static code analysis, you can get a clue that you have to put there 12bytes b64 encoded string.  
So for example this:
```
noname@noname-VirtualBox:~/projects/pwnable/login$ perl -e 'print "A"x12' | base64
QUFBQUFBQUFBQUFB
noname@noname-VirtualBox:~/projects/pwnable/login$ 
```

Having the input ``QUFBQUFBQUFBQUFB``, we can load binary in debug mode, execute it and observe results.

```
[0x08048db8]> ood
Process with PID 4078 started...
File dbg:///home/noname/projects/pwnable/login/login  reopened in read-write mode
= attach 4078 4078
Warning: Cannot initialize dynamic strings
4078
[0x08048db8]> dc
Authenticate : QUFBQUFBQUFBQUFB
hash : ee286cf907828cf6878ff24bf2dd9d4a
child stopped with signal 11
[+] SIGNAL 11 errno=0 addr=0x41414141 code=1 ret=0
[0x08049424]> 
```

Oh. yes. radare2 receives a signal from the kernel that indicates page violations- i.e. executing code from unmapped address.

### display binary info

```
[0x08048db8]> iI
arch     x86
binsz    955184
bintype  elf
bits     32
canary   false
class    ELF32
crypto   false
endian   little
havecode true
lang     c
linenum  true
lsyms    true
machine  Intel 80386
maxopsz  16
minopsz  1
nx       true
os       linux
pcalign  0
pic      false
relocs   true
rpath    NONE
static   true
stripped false
subsys   linux
va       true
```

Having this, you know the base address of ``login`` ELF exec and you can use any gadget from it. This is due to non-PIC , or non-PIE executable. The interpreter will always load this binray to the fixed (entrypoint) address. 

### Finding the gadget
```
[0x0804925f]> s sym.correct
[0x0804925f]> pdf
┌ (fcn) sym.correct 61
│   sym.correct ();
│           ; var int local_ch @ ebp-0xc
│           ; CALL XREF from main (0x804940c)
│           0x0804925f      55             push ebp
│           0x08049260      89e5           mov ebp, esp
│           0x08049262      83ec28         sub esp, 0x28               ; '('
│           0x08049265      c745f440eb11.  mov dword [local_ch], obj.input ; 0x811eb40
│           0x0804926c      8b45f4         mov eax, dword [local_ch]
│           0x0804926f      8b00           mov eax, dword [eax]
│           0x08049271      3defbeadde     cmp eax, 0xdeadbeef
│       ┌─< 0x08049276      7518           jne 0x8049290
│       │   0x08049278      c7042451a60d.  mov dword [esp], 0x80da651  ; [0x80da651:4]=0x676e6f43
│       │   0x0804927f      e84c300100     call sym.puts               ; int puts(const char *s)
│       │   0x08049284      c704246fa60d.  mov dword [esp], 0x80da66f  ; hit0_0 ; [0x80da66f:4]=0x6e69622f ; "/bin/sh"
│       │   0x0804928b      e820200100     call sym.system             ; int system(const char *string)
│       └─> 0x08049290      c70424000000.  mov dword [esp], 0
└           0x08049297      e804140100     call sym.exit               ; void exit(int status)
[0x0804925f]> 
```
