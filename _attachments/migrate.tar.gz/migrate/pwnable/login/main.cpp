/**************************************************************************\
|
| Version
| =======
| version 1.0, January 2012.
| 
| Copyright
| =========
| � Marc Stevens, 2012. All rights reserved.
| Contact: marc @ marc-stevens .nl
| 
| Disclaimer
| ==========
| This software is provided as is. Use is at the user's risk.
| No guarantee whatsoever is given on how it may function or malfunction.
| Support cannot be expected.
| This software is meant for scientific and educational purposes only.
| It is forbidden to use it for other than scientific or educational purposes.
| In particular, commercial and malicious use is not allowed.
| Further distribution of this software, by whatever means, is not allowed
| without our consent.
| This includes publication of source code or executables in printed form,
| on websites, newsgroups, CD-ROM's, etc.
| Changing the (source) code without our consent is not allowed.
| In all versions of the source code this disclaimer, the copyright
| notice and the version number should be present.
|
\**************************************************************************/

#include <stdexcept>
#include <iostream>
#include <fstream>
#include <vector>
#include <string>

#include "main.hpp"

#ifdef USE_BOOST
#include <boost/lexical_cast.hpp>
#endif

using namespace std;

uint64 maxruntime = 0;
timer runtime_sw(true);

int main(int argc, char** argv) 
{
#ifdef USE_BOOST
	if (argc>1) maxruntime = boost::lexical_cast<uint64>(string(argv[1]));
	if (argc>2) {
		uint64 rndseed = boost::lexical_cast<uint64>(string(argv[2]));
		seed(rndseed);
		addseed(rndseed);
		addseed(rndseed>>32);
	}
#endif
	try {
		collisionfinding();
	} catch (exception& e) {
		cerr << "Caught exception!!:" << endl << e.what() << endl;
		return 1;
	} catch (...) {
		cerr << "Unknown exception caught!!" << endl;
		return 1;
	}
	return 0;
}


unsigned load_block(istream& i, uint32 block[])
{	
	for (unsigned k = 0; k < 16; ++k)
		block[k] = 0;

	unsigned len = 0;
	char uc;
	for (unsigned k = 0; k < 16; ++k)
		for (unsigned c = 0; c < 4; ++c)
		{
			i.get(uc);
			if (i) {
				++len;
				block[k] += uint32((unsigned char)(uc)) << (c*8);
			} else {
				i.putback(uc);
				i.setstate(ios::failbit);
				return len;
			}
		}
	return len;
}

void save_block(ostream& o, uint32 block[])
{
	for (unsigned k = 0; k < 16; ++k)
		for (unsigned c = 0; c < 4; ++c)
			o << (unsigned char)((block[k]>>(c*8))&0xFF);
}
