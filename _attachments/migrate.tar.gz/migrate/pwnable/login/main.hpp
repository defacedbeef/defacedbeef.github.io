/**************************************************************************\
|
| Version
| =======
| version 1.0, January 2012.
| 
| Copyright
| =========
| � Marc Stevens, 2012. All rights reserved.
| Contact: marc @ marc-stevens .nl
| 
| Disclaimer
| ==========
| This software is provided as is. Use is at the user's risk.
| No guarantee whatsoever is given on how it may function or malfunction.
| Support cannot be expected.
| This software is meant for scientific and educational purposes only.
| It is forbidden to use it for other than scientific or educational purposes.
| In particular, commercial and malicious use is not allowed.
| Further distribution of this software, by whatever means, is not allowed
| without our consent.
| This includes publication of source code or executables in printed form,
| on websites, newsgroups, CD-ROM's, etc.
| Changing the (source) code without our consent is not allowed.
| In all versions of the source code this disclaimer, the copyright
| notice and the version number should be present.
|
\**************************************************************************/

#ifndef MAIN_HPP
#define MAIN_HPP

#include <iostream>
#include <vector>
#include <string>

using namespace std;

//#define USE_BOOST
#ifdef USE_BOOST
#include <boost/cstdint.hpp>
typedef boost::uint32_t uint32;
typedef boost::uint64_t uint64;
#else
#include <stdint.h>
typedef ::uint32_t uint32;
typedef ::uint64_t uint64;
#endif

inline uint32 rotate_right(const uint32 x, const unsigned n) { return (x>>n) | (x<<(32-n)); }
inline uint32 rotate_left(const uint32 x, const unsigned n) { return (x<<n) | (x>>(32-n)); }

#include "rng.hpp"
#include "timer.hpp"
#include "md5detail.hpp"

	/**** class triple ****/
	template<class Ty1, class Ty2, class Ty3>
	struct triple {
		typedef triple<Ty1, Ty2, Ty3> MyType;
		typedef Ty1 first_type;
		typedef Ty2 second_type;
		typedef Ty3 third_type;

		triple()
			: first(Ty1()), second(Ty2()), third(Ty3()) 
		{}

		triple(const Ty1& val1, const Ty2& val2, const Ty3& val3)
			: first(val1), second(val2), third(val3)
		{}

		template<class O1, class O2, class O3>
		triple(const triple<O1, O2, O3>& r)
			: first(r.first), second(r.second), third(r.third)
		{}

		void swap(MyType& r)
		{
			std::swap(first, r.first);
			std::swap(second, r.second);
			std::swap(third, r.third);
		}

		first_type first;
		second_type second;
		third_type third;
	};

	template<class Ty1, class Ty2, class Ty3>
	inline triple<Ty1,Ty2,Ty3> make_triple(Ty1 v1, Ty2 v2, Ty3 v3)
	{ 
		return triple<Ty1,Ty2,Ty3>(v1,v2,v3); 
	}

	template<class Ty1, class Ty2, class Ty3>
	inline bool operator==(const triple<Ty1, Ty2, Ty3>& l, const triple<Ty1, Ty2, Ty3>& r)
	{
		return l.first==r.first && l.second==r.second && l.third==r.third;
	}

	template<class Ty1, class Ty2, class Ty3>
	inline bool operator!=(const triple<Ty1, Ty2, Ty3>& l, const triple<Ty1, Ty2, Ty3>& r)
	{	return !(l == r); }

	template<class Ty1, class Ty2, class Ty3>
	inline bool operator<(const triple<Ty1, Ty2, Ty3>& l, const triple<Ty1, Ty2, Ty3>& r)
	{
		return l.first<r.first || (l.first==r.first && (l.second<r.second || (l.second==r.second && l.third<r.third)));
	}

	template<class Ty1, class Ty2, class Ty3>
	inline bool operator>(const triple<Ty1, Ty2, Ty3>& l, const triple<Ty1, Ty2, Ty3>& r)
	{	return r<l;	}

	template<class Ty1, class Ty2, class Ty3>
	inline bool operator<=(const triple<Ty1, Ty2, Ty3>& l, const triple<Ty1, Ty2, Ty3>& r)
	{	return !(r<l); }

	template<class Ty1, class Ty2, class Ty3>
	inline bool operator>=(const triple<Ty1, Ty2, Ty3>& l, const triple<Ty1, Ty2, Ty3>& r)
	{	return !(l<r); }

	template<class Ty1, class Ty2, class Ty3>
	inline void swap(triple<Ty1,Ty2,Ty3>& l, triple<Ty1,Ty2,Ty3>& r)
	{	l.swap(r);	}

unsigned load_block(istream& i, uint32 block[]);
void save_block(ostream& o, uint32 block[]);

int collisionfinding();

extern uint64 maxruntime;
extern timer runtime_sw;

#endif // MAIN_HPP
