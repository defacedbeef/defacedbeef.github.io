/**************************************************************************\
|
| Version
| =======
| version 1.0, January 2012.
| 
| Copyright
| =========
| � Marc Stevens, 2012. All rights reserved.
| Contact: marc @ marc-stevens .nl
| 
| Disclaimer
| ==========
| This software is provided as is. Use is at the user's risk.
| No guarantee whatsoever is given on how it may function or malfunction.
| Support cannot be expected.
| This software is meant for scientific and educational purposes only.
| It is forbidden to use it for other than scientific or educational purposes.
| In particular, commercial and malicious use is not allowed.
| Further distribution of this software, by whatever means, is not allowed
| without our consent.
| This includes publication of source code or executables in printed form,
| on websites, newsgroups, CD-ROM's, etc.
| Changing the (source) code without our consent is not allowed.
| In all versions of the source code this disclaimer, the copyright
| notice and the version number should be present.
|
\**************************************************************************/

#include <cmath>
#include <algorithm>
#include <map>
#include <stdexcept>

#include "main.hpp"

#define UPDATE(s)

uint64 tendcount = 0;
vector<uint64> testcounts(1<<8,0);

uint32 m_diff[16];

vector< triple<uint32,uint32,uint32> > Q1Q2m0withm1ok;
vector< triple<uint32,uint32,uint32> >::const_iterator Q1Q2m0it, Q1Q2m0itend;

#define CONSTTABLES
const uint32 dQ[68] = { 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000001, 0x00000001, 0x00000001, 0x00000001, 0x00000201, 0x00001a01, 0x00021a01, 0x01021a00, 0x01461a20, 0x0da65e22, 0xda1ea154, 0xe040080a, 0x0810ffc0, 0x17e0f7b0, 0x0021f830, 0xffc00050, 0xfde00051, 0xffc00080, 0x7dfffff0, 0x81fff7f0, 0xfdff0010, 0x7e000010, 0x7fffff10, 0xffffff00, 0xfff00000, 0x7ff00000, 0x80000000, 0x00000000, 0x00000000, 0x80000000, 0x80000000, 0x80000000, 0x80000000, 0x80000000, 0x80000000, 0x80000000, 0x80000000, 0x80000000, 0x80000000, 0x80000000, 0x80000000, 0x80000000, 0x80000000, 0x80000000, 0x80000000, 0x80000000, 0x80000000, 0x80000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000};
const uint32 dT[68] = { 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x02000000, 0x00000000, 0x00000000, 0x00000000, 0x00000004, 0x80000001, 0x00000001, 0xfffffc04, 0x00022001, 0x01063022, 0x0cc731e1, 0x166b6062, 0xb13e87be, 0xf807e7fc, 0x01ffa104, 0xe081fffa, 0x07f10000, 0x1780f000, 0xfdc1f900, 0xff800040, 0xfbdff841, 0xffc00080, 0xfc000800, 0xfffef800, 0xffff0010, 0x00100000, 0x00000010, 0xffffff00, 0x00000000, 0xfff00000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x02000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000};
const uint32 dR[68] = { 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000001, 0x00000000, 0x00000000, 0x00000000, 0x00000200, 0x00001800, 0x00020000, 0x00ffffff, 0x00440020, 0x0c604402, 0xcc784332, 0x062166b6, 0x27d0f7b6, 0x0fcff7f0, 0xe8410080, 0xff9e0820, 0xfe200001, 0x01e0002f, 0x7e3fff70, 0x03fff800, 0x7bff0820, 0x80010000, 0x01ffff00, 0x7ffffff0, 0xfff00100, 0x80000000, 0x00100000, 0x80000000, 0x00000000, 0x80000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x80000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000};
const uint32 Qvaluemask[68] = { 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0xeb78d1dc, 0xffffffff, 0xffffffff, 0x14872e23, 0x00000001, 0x00000003, 0xfffffdff, 0xfffffdbf, 0xffffffbf, 0x00002603, 0x0b702e1f, 0xeb7affdf, 0xeb7effff, 0xffffffff, 0x4dfffff7, 0x7ffffffe, 0x7bfffffe, 0x3efbeffa, 0x7a73dff4, 0x2863085a, 0x0a730851, 0x2a6108d1, 0x826208d1, 0x024008d0, 0x02210851, 0x02410890, 0x02010910, 0x02010810, 0x02010110, 0x02100100, 0x80100010, 0x80100100, 0x80000000, 0x00100000, 0x80000000, 0x80000000, 0x80000000, 0x80000000, 0x80000000, 0x80000000, 0x80000000, 0x80000000, 0x80000000, 0x80000000, 0x80000000, 0x80000000, 0x80000000, 0x80000000, 0x80000000, 0x80000000, 0x80000000, 0x80000000, 0x80000000, 0x80000000, 0x80000000, 0x80000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000};
const uint32 Qvalue[68] = { 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x40085000, 0x00000000, 0xeb78d1dc, 0x14872e23, 0x00000000, 0x00000000, 0x00000041, 0x00000000, 0xfffffdbe, 0x00002001, 0x00002000, 0x40085602, 0x00040621, 0x14810a21, 0x08009740, 0x2dabc8e8, 0x410f3f70, 0x30936430, 0x3252c260, 0x08420850, 0x08200810, 0x08400081, 0x02200880, 0x00400850, 0x02000850, 0x00010810, 0x02010800, 0x02000000, 0x02010100, 0x00100100, 0x80100010, 0x00100100, 0x00000000, 0x00100000, 0x80000000, 0x00000000, 0x00000000, 0x80000000, 0x80000000, 0x80000000, 0x80000000, 0x80000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x80000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000};
const uint32 Qprev[68] = { 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000002, 0x00000040, 0x00000000, 0x00000000, 0x00000000, 0x0b70001c, 0x00020000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x04000000, 0x40001004, 0x0000000a, 0x00100000, 0x20000000, 0x00020000, 0x00000000, 0x00200001, 0x00400080, 0x00000000, 0x00000000, 0x00000000, 0x00100000, 0x80000010, 0x00000100, 0x00000000, 0x00100000, 0x80000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000};
const uint32 Qprev2[68] = { 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000};

const int offset = 3;
uint32 m[16];
uint32 m2[16];
uint32 Q[68];
uint32 Q2[68];


inline bool checkrotation(uint32 Qt, uint32 Qtp1, uint32 dT, uint32 dR, unsigned rc)
{
	uint32 R1 = Qtp1-Qt;
	uint32 R2 = R1 + dR;
	uint32 T1 = rotate_right(R1, rc);
	uint32 T2 = rotate_right(R2, rc);
	return (T2-T1 == dT);
}

struct Q3Q6Q7 {
	uint32 Q3,Q6,Q7,Q13,F15;
	Q3Q6Q7(uint32 Q3_ = 0, uint32 Q6_ = 0, uint32 Q7_ = 0, uint32 Q13_ = 0, uint32 F15_ = 0): Q3(Q3_), Q6(Q6_), Q7(Q7_),Q13(Q13_),F15(F15_) {}
};
inline bool operator<(const Q3Q6Q7& l, const Q3Q6Q7& r) { return l.Q7 < r.Q7; }

struct Q12Q911F10 {
	uint32 Q12,Q911,F10;
	Q12Q911F10(uint32 Q12_ = 0, uint32 Q911_ = 0, uint32 F10_ = 0): Q12(Q12_), Q911(Q911_), F10(F10_) {}
};
inline bool operator<(const Q12Q911F10& l, const Q12Q911F10& r) { return l.F10 < r.F10; }

vector< vector<uint32> > vQok;

void checkcalc(int tend)
{
	for (int t = 0; t < 16; ++t)
		m[t] = rotate_right(Q[offset+t+1]-Q[offset+t],md5_rc[t]) - md5_ac[t] - md5_ff(Q[offset+t],Q[offset+t-1],Q[offset+t-2]) - Q[offset+t-3];
#if 0
	for (int t = 16; t < tend; ++t) {
		uint32 Qtp1 = Q[offset+t] + rotate_left(md5_gg(Q[offset+t],Q[offset+t-1],Q[offset+t-2]) + md5_ac[t] + Q[offset+t-3] + m[md5_wt[t]], md5_rc[t]);
		if (Qtp1 != Q[offset+t+1]) {
			cout << "Inconsistency: Q" << (t+1) << " or m" << md5_wt[t] << " incorrectly computed!" << endl;
		}
	}
	for (int t = -2; t <= tend; ++t) {
		if (t==3 || t==4 || t==9 || t==14) continue; // tunnels
		if (Qvalue[offset+t] != ((Q[offset+t]&Qvaluemask[offset+t]) ^ (Qprev[offset+t]&Q[offset+t-1]))) {
			cout << "Conditions not fulfilled on Q" << t << endl;
		}
	}
#endif
	for (int t = 0; t < 16; ++t)
		m2[t] = m[t] + m_diff[t];
	uint32 ihv[5], ihv2[5];
	for (int t = 0; t < 5; ++t)
		ihv2[t] = ihv[t] = md5_iv[t];
	md5compress(ihv,m);
	md5compress(ihv2,m2);
	if (ihv[0] == ihv2[0] && ihv[1] == ihv2[1] && ihv[2] == ihv2[2] && ihv[3]==ihv2[3] && ihv[4]==ihv2[4]) {
		cout << "Found collision!" << endl;
		for (int t = 0; t < 16; ++t)
			cout << m[t] << endl;
		cout << endl;
		for (int t = 0; t < 16; ++t)
			cout << m2[t] << endl;
		throw std::runtime_error("found collision!");
	}
}
timer runtimesw(true);

void step25()
{
	static uint64 Q29ok = 0;
	m[8] = rotate_right(Q[offset+9]-Q[offset+8], md5_rc[8]) - md5_ff(Q[offset+8],Q[offset+7],Q[offset+6]) - Q[offset+5] - md5_ac[8];
	const uint32 Q14tunnel = 0xEB78D1DC ^ 0x0B70001C;
	const uint32 Q14tunnel2 = 0x0B70001C;
	const uint32 Q26pc = md5_gg(Q[offset+25],Q[offset+24],Q[offset+23]) + Q[offset+22] + md5_ac[25];
	const uint32 Q26val = Qvalue[offset+26];
	const uint32 Q26mask = Qvaluemask[offset+26];
	uint32 Q14cur = 0, Q14val = Q[offset+14], Q3val = Q[offset+3];
	do {
		Q14cur -= 1; Q14cur &= Q14tunnel;
		Q[offset+14] = Q14val ^ Q14cur;
		m[14] = rotate_right(Q[offset+15]-Q[offset+14], md5_rc[14]) - md5_ff(Q[offset+14],Q[offset+13],Q[offset+12]) - Q[offset+11] - md5_ac[14];
		Q[offset+26] = Q[offset+25] + rotate_left(Q26pc + m[14], md5_rc[25]);
		if (Q26val != (Q[offset+26]&Qvaluemask[offset+26])) continue;

		uint32 Q14cur2 = 0, Q26val2 = Q[offset+26], Q3val2 = Q3val ^ Q14cur;
		do {
			Q14cur2 -= 1; Q14cur2 &= Q14tunnel2;
		Q[offset+26] = Q26val2 - rotate_right(Q14cur2,8);
		Q[offset+3] = Q3val2 ^ Q14cur2;
		m[3] = rotate_right(Q[offset+4]-Q[offset+3], md5_rc[3]) - md5_ff(Q[offset+3],Q[offset+2],Q[offset+1]) - Q[offset+0] - md5_ac[3];
		Q[offset+27] = Q[offset+26] + rotate_left(md5_gg(Q[offset+26],Q[offset+25],Q[offset+24])+Q[offset+23]+md5_ac[26]+m[3], md5_rc[26]);
		if ( (Qvalue[offset+27]^(Q[offset+26]&Qprev[offset+27])) != (Q[offset+27]&Qvaluemask[offset+27]) ) continue;
		if (!checkrotation(Q[offset+26],Q[offset+27],dT[offset+26],dR[offset+26],md5_rc[26])) continue;

		Q[offset+14] = Q14val ^ Q14cur ^ Q14cur2;
		m[14] = rotate_right(Q[offset+15]-Q[offset+14], md5_rc[14]) - md5_ff(Q[offset+14],Q[offset+13],Q[offset+12]) - Q[offset+11] - md5_ac[14];
		const uint32 Q26correct = Q[offset+25] + rotate_left(Q26pc + m[14], md5_rc[25]);
		if (Q[offset+26] != Q26correct) {
			Q[offset+26] = Q26correct;
			Q[offset+27] = Q[offset+26] + rotate_left(md5_gg(Q[offset+26],Q[offset+25],Q[offset+24])+Q[offset+23]+md5_ac[26]+m[3], md5_rc[26]);
			if ( (Qvalue[offset+27]^(Q[offset+26]&Qprev[offset+27])) != (Q[offset+27]&Qvaluemask[offset+27]) ) continue;
			if (!checkrotation(Q[offset+26],Q[offset+27],dT[offset+26],dR[offset+26],md5_rc[26])) continue;
		}

		Q[offset+28] = Q[offset+27] + rotate_left(md5_gg(Q[offset+27],Q[offset+26],Q[offset+25])+Q[offset+24]+md5_ac[27]+m[8], md5_rc[27]);
		if ( (Qvalue[offset+28]^(Q[offset+27]&Qprev[offset+28])) != (Q[offset+28]&Qvaluemask[offset+28]) ) continue;
		if (!checkrotation(Q[offset+26],Q[offset+27],dT[offset+26],dR[offset+26],md5_rc[26])) continue;
		if (!checkrotation(Q[offset+27],Q[offset+28],dT[offset+27],dR[offset+27],md5_rc[27])) continue;

		m[13] = rotate_right(Q[offset+14]-Q[offset+13], md5_rc[13]) - md5_ff(Q[offset+13],Q[offset+12],Q[offset+11]) - Q[offset+10] - md5_ac[13];
		Q[offset+29] = Q[offset+28] + rotate_left(md5_gg(Q[offset+28],Q[offset+27],Q[offset+26])+Q[offset+25]+md5_ac[28]+m[13], md5_rc[28]);
		if ( (Qvalue[offset+29]^(Q[offset+28]&Qprev[offset+29])) != (Q[offset+29]&Qvaluemask[offset+29]) ) continue;
		if (!checkrotation(Q[offset+28],Q[offset+29],dT[offset+28],dR[offset+28],md5_rc[28])) continue;

		if (Q26val != (Q[offset+26]&Qvaluemask[offset+26])) continue;
		if (!checkrotation(Q[offset+25],Q[offset+26],dT[offset+25],dR[offset+25],md5_rc[25])) continue;

		++Q29ok;
		checkcalc(29);

		if ((Q29ok&0xFFF)==0) {
			cout << "Q29ok:\t" << Q29ok << "#\t 2^" << log(double(Q29ok)/runtimesw.time())/log(2.0) << "#/s \t " << runtimesw.time() << endl;
			if (maxruntime && double(maxruntime) < runtime_sw.time()) exit(0);
		}
		
		} while (Q14cur2 != 0);
	} while (Q14cur != 0);
	// restore changed values
	Q[offset+14] = Q14val;
	Q[offset+3] = Q3val;
}

void step24()
{
	static uint64 Q25ok = 0;
	const uint32 Q9tunnel = 0xFFFFFDBC;
	const uint32 Q25pc = md5_gg(Q[offset+24],Q[offset+23],Q[offset+22]) + Q[offset+21] + md5_ac[24];
	const uint32 Q25val = Qvalue[offset+25]^(Q[offset+24]&Qprev[offset+25]);
	uint32 Q9cur = 0, Q9val = Q[offset+9];
	do {
		Q9cur -= 1; Q9cur &= Q9tunnel;
		Q[offset+9] = Q9val ^ Q9cur;
		m[9] = rotate_right(Q[offset+10]-Q[offset+9], md5_rc[9]) - md5_ff(Q[offset+9],Q[offset+8],Q[offset+7]) - Q[offset+6] - md5_ac[9];
		Q[offset+25] = Q[offset+24] + rotate_left(Q25pc + m[9], md5_rc[24]);
		if (Q25val != (Q[offset+25]&Qvaluemask[offset+25])) continue;
		if (!checkrotation(Q[offset+24],Q[offset+25],dT[offset+24],dR[offset+24],md5_rc[24])) continue;
		
		if ((Q[offset+25]&0x28)==0) continue;

		step25();
	} while (Q9cur != 0);
	// restore changed values
	Q[offset+9] = Q9val;
}


void step23()
{
	const uint32 Q4tunnel = 0x14872E23;
	const uint32 Q24pc = md5_gg(Q[offset+23],Q[offset+22],Q[offset+21]) + Q[offset+20] + md5_ac[23];
	const uint32 Q24val = Qvalue[offset+24]^(Q[offset+23]&Qprev[offset+24]);
	uint32 Q4cur = 0, Q4val = Q[offset+4];
	do {
		Q4cur -= 1; Q4cur &= Q4tunnel;
		Q[offset+4] = Q4val ^ Q4cur;
		m[4] = rotate_right(Q[offset+5]-Q[offset+4], md5_rc[4]) - md5_ff(Q[offset+4],Q[offset+3],Q[offset+2]) - Q[offset+1] - md5_ac[4];
		Q[offset+24] = Q[offset+23] + rotate_left(Q24pc + m[4], md5_rc[23]);
		if (Q24val != (Q[offset+24]&Qvaluemask[offset+24])) continue;
		if (!checkrotation(Q[offset+23],Q[offset+24],dT[offset+23],dR[offset+23],md5_rc[23])) continue;

		step24();
	} while (Q4cur != 0);
	// restore changed values
	Q[offset+4] = Q4val;
}

typedef map<pair<uint32,uint32>, vector<Q3Q6Q7> > Q3Q6map_t;
void collinit()
{
	static Q3Q6map_t mQ3Q6Q7;
	
	for (Q3Q6map_t::iterator it = mQ3Q6Q7.begin(); it != mQ3Q6Q7.end(); ++it)
		it->second.clear();

	// Instantiation
	while (true) {
		Q[offset+14] = (xrng128() & ((~Qvaluemask[offset+14])|Qprev[offset+14]) ) ^ Qvalue[offset+14];
		bool rotok = true;
		for (int t = 15; t <= 21; ++t) {
			Q[offset+t] = (xrng128()&~Qvaluemask[offset+t]) ^ Qvalue[offset+t] ^ (Qprev[offset+t]&Q[offset+t-1]);
			if (!checkrotation(Q[offset+t-1],Q[offset+t],dT[offset+t-1],dR[offset+t-1],md5_rc[t-1])) {
				rotok = false;
				break;
			}
		}
		if (rotok) break;
	}
	m[6]  = rotate_right(Q[offset+18]-Q[offset+17], 9 ) - md5_gg(Q[offset+17],Q[offset+16],Q[offset+15]) - md5_ac[17] - Q[offset+14];
	m[11] = rotate_right(Q[offset+19]-Q[offset+18], 14) - md5_gg(Q[offset+18],Q[offset+17],Q[offset+16]) - md5_ac[18] - Q[offset+15];
	m[0]  = rotate_right(Q[offset+20]-Q[offset+19], 20) - md5_gg(Q[offset+19],Q[offset+18],Q[offset+17]) - md5_ac[19] - Q[offset+16];
	m[5]  = rotate_right(Q[offset+21]-Q[offset+20], 5 ) - md5_gg(Q[offset+20],Q[offset+19],Q[offset+18]) - md5_ac[20] - Q[offset+17];
	Q[offset+1] = Q[offset+0] + rotate_left(md5_ff(Q[offset+0],Q[offset-1],Q[offset-2]) + md5_ac[0] + Q[offset-3] + m[0], 7);

	// Precompute lookup table
	Q[offset+4] = (xrng128()&~Qvaluemask[offset+4]) ^ Qvalue[offset+4];
	Q[offset+5] = (xrng128()&~Qvaluemask[offset+5]) ^ Qvalue[offset+5];
	uint64 Q3Q6cnt = 0;
	{
		uint32 Q13pc = rotate_right(Q[offset+17]-Q[offset+16], md5_rc[16]) - md5_gg(Q[offset+16],Q[offset+15],Q[offset+14]) - md5_ac[16];
		uint32 Q13mask = (Qvaluemask[offset+13]|Qprev[offset+14])&~Qprev[offset+13];
		uint32 Q13val = (Qvalue[offset+13]&Q13mask) ^ ((Qvalue[offset+14]^Q[offset+14])&Qprev[offset+14]);
		uint32 m1pc = md5_ff(Q[offset+1],Q[offset-0],Q[offset-1]) + md5_ac[1] + Q[offset-2];

		uint32 Q6cur = 0;
		do {
			Q6cur -= 1; Q6cur &= ~Qvaluemask[offset+6];
			Q[offset+6] = Q6cur ^ Qvalue[offset+6];
			uint32 Q7pc = md5_ff(Q[offset+6],Q[offset+5],Q[offset+4]) + md5_ac[6] + m[6];
			uint32 Q7val = Qvalue[offset+7] ^ (Q[offset+6]&Qprev[offset+7]);
			uint32 Q2pc = rotate_right(Q[offset+6]-Q[offset+5],md5_rc[5]) - md5_ac[5] - m[5];
			uint32 Q3cur = 0;
			do {
				Q3cur -= 1; Q3cur &= ~Qvaluemask[offset+3];
				Q[offset+3] = Q3cur ^ Qvalue[offset+3];
				Q[offset+7] = Q[offset+6] + rotate_left(Q7pc + Q[offset+3], md5_rc[6]);
				if (Q7val != (Q[offset+7]&Qvaluemask[offset+7])) continue;
				Q[offset+2] = Q2pc - md5_ff(Q[offset+5],Q[offset+4],Q[offset+3]);
				m[1] = rotate_right(Q[offset+2]-Q[offset+1], md5_rc[1]) - m1pc;
				Q[offset+13] = Q13pc - m[1];
				if (Q13val != (Q[offset+13]&Q13mask)) continue;
				if (!checkrotation(Q[offset+13],Q[offset+14],dT[offset+13],dR[offset+13],12)) continue;
				pair<uint32,uint32> Q7Q13(Q[offset+7]&Qprev[offset+8], Q[offset+13]&Qprev[offset+13]);
				mQ3Q6Q7[Q7Q13].push_back(Q3Q6Q7(Q[offset+3],Q[offset+6],Q[offset+7],Q[offset+13],md5_ff(Q[offset+15],Q[offset+14],Q[offset+13]) ));
				++Q3Q6cnt;
			} while (Q3cur != 0);
		} while (Q6cur != 0);
	}
	cout << "#Q3Q6: " << Q3Q6cnt << endl;
	if (Q3Q6cnt == 0) return;
	if (Q3Q6cnt < (1<<24)) return;

	// Main loop
	runtimesw.start();	
	uint64 Q8ok = 0, Q22Q23ok = 0;
	uint32 Q9cur = 0, Q9mask = (~Qvaluemask[offset+9])|Qprev[offset+9], Q9val = Qvalue[offset+9]&~Q9mask;
	do {
		Q9cur -= 1; Q9cur &= Q9mask; Q[offset+9] = Q9cur ^ Q9val;
		uint32 Q10cur = 0;
		do {
			Q10cur -= 1; Q10cur &= ~Qvaluemask[offset+10]; Q[offset+10] = Q10cur ^ Qvalue[offset+10];
			uint32 Q11cur = 0;
			do {
				Q11cur -= 1; Q11cur &= ~Qvaluemask[offset+11]; Q[offset+11] = Q11cur ^ Qvalue[offset+11];
				uint32 Q8pc = md5_ff(Q[offset+11],Q[offset+10],Q[offset+9]) + md5_ac[11] + m[11];
				uint32 Q8mask = (Qvaluemask[offset+8]&~Qprev[offset+8])|Qprev[offset+9];
				uint32 Q8val = (Qvalue[offset+8]&Q8mask)^((Q[offset+9]^Qvalue[offset+9])&Qprev[offset+9]);
				uint32 Q12cur = 0;
				do {
					Q12cur -= 1; Q12cur &= ~Qvaluemask[offset+12]; Q[offset+12] = Q12cur ^ Qvalue[offset+12];
					Q[offset+8] = rotate_right(Q[offset+12]-Q[offset+11], md5_rc[11]) - Q8pc;
					if (Q8val != (Q[offset+8]&Q8mask)) continue;
					pair<uint32,uint32> Q7Q13;
					Q7Q13.first = (Q[offset+8]^Qvalue[offset+8])&Qprev[offset+8];
					Q7Q13.second = (Q[offset+12]^Qvalue[offset+13])&Qprev[offset+13];

					uint32 m10pc = rotate_right(Q[offset+11]-Q[offset+10], md5_rc[10]) - md5_ff(Q[offset+10],Q[offset+9],Q[offset+8]) - md5_ac[10];
					uint32 Q22pc = md5_gg(Q[offset+21],Q[offset+20],Q[offset+19]) + md5_ac[21] + Q[offset+18]; 
					uint32 Q22val = Qvalue[offset+22]^(Q[offset+21]&Qprev[offset+22]);
					uint32 m15pc = rotate_right(Q[offset+16]-Q[offset+15], md5_rc[15]) - Q[offset+12] - md5_ac[15];
					const vector<Q3Q6Q7>& vQ3Q6Q7 = mQ3Q6Q7[Q7Q13];
					Q8ok += vQ3Q6Q7.size();
					for (vector<Q3Q6Q7>::const_iterator cit = vQ3Q6Q7.begin(); cit != vQ3Q6Q7.end(); ++cit) {
						m[10] = m10pc - cit->Q7;
						Q[offset+22] = Q[offset+21] + rotate_left(Q22pc + m[10], md5_rc[21]);
						if (Q22val != (Q[offset+22]&Qvaluemask[offset+22])) continue;
						m[15] = m15pc - md5_ff(Q[offset+15],Q[offset+14],cit->Q13);
						Q[offset+23] = Q[offset+22] + rotate_left(md5_gg(Q[offset+22],Q[offset+21],Q[offset+20]) + md5_ac[22] + m[15] + Q[offset+19], md5_rc[22]);
						if (Qvalue[offset+23] != ( (Q[offset+23]&Qvaluemask[offset+23]) ^ (Q[offset+22]&Qprev[offset+23]) )) continue;
						if (!checkrotation(Q[offset+21],Q[offset+22],dT[offset+21],dR[offset+21],md5_rc[21])) continue;
						if (!checkrotation(Q[offset+22],Q[offset+23],dT[offset+22],dR[offset+22],md5_rc[22])) continue;
						Q[offset+3] = cit->Q3;
						Q[offset+6] = cit->Q6;
						Q[offset+7] = cit->Q7;
						Q[offset+13] = cit->Q13;
						Q[offset+2] = rotate_right(Q[offset+6]-Q[offset+5], md5_rc[5]) - md5_ff(Q[offset+5],Q[offset+4],Q[offset+3]) - md5_ac[5] - m[5];
						step23();
					}
				} while (Q12cur != 0);
			} while (Q11cur != 0);
		} while (Q10cur != 0);
	} while (Q9cur != 0);		
	cout << "#Q8ok: " << Q8ok << endl;
}

void filltables()
{
	for (unsigned i = 0; i < 16; ++i)
		m_diff[i] = 0;
	m_diff[8] = 1<<25;
	m_diff[13] = 1<<31;

	Q[0] = md5_iv[0]; Q2[0] = Q[0] + dQ[0];
	Q[1] = md5_iv[3]; Q2[1] = Q[1] + dQ[1];
	Q[2] = md5_iv[2]; Q2[2] = Q[2] + dQ[2];
	Q[3] = md5_iv[1]; Q2[3] = Q[3] + dQ[3];
}

int collisionfinding()
{
	filltables();

	cout << "Starting..." << endl;
	while (true) collinit();
	return 0;
}

