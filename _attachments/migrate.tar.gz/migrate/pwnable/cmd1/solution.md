export TEST_ENV=flag
./cmd1 "/bin/cat \$TEST_ENV"
