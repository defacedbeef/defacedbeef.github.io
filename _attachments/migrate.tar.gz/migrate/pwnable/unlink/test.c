#include <stdlib.h>
#include <stdio.h>
typedef struct tag {
	struct tag* fd;
} obj;

int main()
{
	obj* a = (obj*) malloc(sizeof(obj));
	a->fd = (obj*)malloc(sizeof(obj));
	
	obj* b = a->fd;
	
}
