#include <stdio.h>
#include <stdlib.h>
#include <limits.h>


int main (int ac, char **av) {
    int a = abs(INT_MAX+1);
    int b = a % 7;
    printf("%ul\n", a);
    printf("%d\n", b);
}
