gdb-multiarch -x ./gdb.cmd
