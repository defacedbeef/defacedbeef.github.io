"""
write what where sample (x64)

g1: 0x400890: pop r14; pop r15; ret
g3: 0x400893: pop rdi; ret

"""

