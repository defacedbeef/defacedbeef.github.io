
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
__attribute__((constructor)) void foo(void)
{
    char buffer[128];
    memset(buffer,0,sizeof(buffer));
    int fd = open("flag", O_RDONLY);
    read(fd, buffer, 32);
    close(fd);
    printf("%s\n", buffer);
    exit(0);
}
