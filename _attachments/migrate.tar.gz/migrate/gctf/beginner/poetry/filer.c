#include <unistd.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>


void *print_message_function( void *ptr );

int main()
{
    int fd = open("/tmp/success", O_CREAT | O_RDWR);
    close(fd);
}
