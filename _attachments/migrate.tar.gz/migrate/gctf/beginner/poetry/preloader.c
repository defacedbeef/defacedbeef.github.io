#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

__attribute__((constructor))
void gimmeflag()
{
    printf(";-)\n");
    exit(0);
}
