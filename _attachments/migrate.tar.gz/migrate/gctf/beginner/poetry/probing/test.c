#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <pthread.h>

int master = 1;
int slave = 0;

int* ptr_master = &master;
int* ptr_slave = &slave;


void *execute_poetry( void *ptr );



int main()
{
    pthread_t thread1, thread2;
    pthread_create( &thread1, NULL, execute_poetry, (void*) ptr_master);
    pthread_create( &thread2, NULL, execute_poetry, (void*) ptr_slave);

    pthread_join(thread1,NULL);
    pthread_join(thread2,NULL);
}


void* execute_poetry(void* master)
{
    int* ptr = (int*)master;

    char *argv[] = {"./poetry","/home/noname/projects/gctf/beginner/poetry/filer", NULL};
    char *env[] = { "LD_BIND_NOW=0", NULL };
    
    if(*ptr)
    {
        printf("executing master\n");
        execve("./poetry", argv, NULL);
    }
    else
    {   
        printf("executing slave\n");
        execve("./poetry", argv, env);
    }
}
