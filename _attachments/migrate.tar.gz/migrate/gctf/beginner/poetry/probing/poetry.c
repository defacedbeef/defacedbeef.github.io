#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>

       pid_t getpid(void);


int main()
{

    char buffer[1024];
    pid_t getpid();
    printf("pid: %d, buffer: %p\n", getpid(),buffer);
}
