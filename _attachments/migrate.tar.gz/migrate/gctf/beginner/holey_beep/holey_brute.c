
#include <signal.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>

void bruteforce(int ms, char** av)
{
    
    char* newargv[] = {"./holey_beep", av[1], NULL};
    pid_t pid = fork();
    if(pid == 0)
    {
        execve("./holey_beep", newargv, NULL);
    }
    else    
    {
        usleep(ms*100);
        kill(pid, 15);
    } 
}

int main(int ac, char** av)
{
    for(int i = 0 ; i < atoi(av[2]); i++)
        bruteforce(i, av);
}
