#include <stdio.h>
#include <string.h>


int main(int ac, char** av)
{
    printf("%s\n", av[1]);
    printf("%p\n", av[1]);
    printf("%p\n", strtok(av[1], "/"));
    printf("%s\n", av[1]);
}
