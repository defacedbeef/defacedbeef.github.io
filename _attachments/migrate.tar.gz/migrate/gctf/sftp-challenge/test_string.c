#include <stdlib.h>
#include <stdio.h>
#include <string.h>

const char* prefix = "";

extern int bruteforce(void* addr);


int main(int ac, char** av)
{

	unsigned long i = 0;
	char *str;

	char low = (char)atoi(av[1]);
	char high = (char)atoi(av[2]);

	printf("low: %d\n high: %d\n", low, high);

//	char low = 0x20;
//	char high = 0x7e;

	str = (char *)malloc(128);
	if(str == NULL) exit(1);
	memset(str, '\0',  128);
	while(1) 
	{
		// incrementally generating input (str) strings:
		char *cur = str;

		while(*cur == high) {
			*cur = low;
			cur++;
		}

		if (*cur == 0) {
			*cur = low;
		} else {
			*cur = *cur + 1;
		}

		if(bruteforce(str))
		{
			printf("%s\n", str);
			return 0;
		}
	}
} 
